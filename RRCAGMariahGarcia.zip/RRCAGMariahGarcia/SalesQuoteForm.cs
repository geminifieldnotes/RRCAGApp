﻿using Garcia.Mariah.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RRCAGMariahGarcia
{
    public partial class SalesQuoteForm : Form
    {
        public SalesQuoteForm()
        {
            InitializeComponent();

            txtVehiclesSalesPrice.TextChanged += new EventHandler(txtVehiclesSalesPrice_TextChanged);
            txtTradeInValue.TextChanged += new EventHandler(txtTradeInValue_TextChanged);

            txtSummaryVehiclesSalePrice.TextChanged += new EventHandler(txtSummaryVehiclesSalePrice_TextChanged);
            txtSummaryOptions.TextChanged += new EventHandler(txtSummaryOptions_TextChanged);
            txtSummaryTradeIn.TextChanged += new EventHandler(txtSummaryTradeIn_TextChanged);
            txtSummarySubtotal.TextChanged += new EventHandler(txtSummarySubtotal_TextChanged);
            txtSummaryTax.TextChanged += new EventHandler(txtSummaryTax_TextChanged);
            txtSummaryTotal.TextChanged += new EventHandler(txtSummaryTotal_TextChanged);
            txtSummaryAmountDue.TextChanged += new EventHandler(txtSummaryAmountDue_TextChanged);

            txtFinanceMonthlyPay.TextChanged += new EventHandler(txtFinanceMonthlyPay_TextChanged);

            btnReset.Click += new EventHandler(btnReset_Click);
        
    }

        private void SalesQuoteForm_Load(object sender, EventArgs e)
        {
            btnReset.Click += new EventHandler(btnReset_Click);
        }

        private void txtVehiclesSalesPrice_TextChanged(object sender, EventArgs e)
        {
            decimal number;
            if (txtVehiclesSalesPrice.Text == null || txtVehiclesSalesPrice.Text.Equals(String.Empty))
            {
                Console.WriteLine("Vehicle price is a required field.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            } else if(decimal.Parse(txtVehiclesSalesPrice.Text) <= 0)
            {
                Console.WriteLine("Vehicle price cannot be less than or equal to 0.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            } else if(decimal.TryParse(txtVehiclesSalesPrice.Text, out number) == true)
            {
                Console.WriteLine("Vehicle price cannot contain letters or special characters.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null; 
            }
        }

        private void txtTradeInValue_TextChanged(object sender, EventArgs e)
        {
            decimal number;
            if (txtTradeInValue.Text == null || txtTradeInValue.Text.Equals(String.Empty))
            {
                Console.WriteLine("Trade-in value is a required field.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            }
            else if (decimal.Parse(txtTradeInValue.Text) <= 0)
            {
                Console.WriteLine("Trade-in value cannot be less than or equal to 0.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            }
            else if (decimal.TryParse(txtTradeInValue.Text, out number) == true)
            {
                Console.WriteLine("Trade-in value cannot contain letters or special characters.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            } else if(decimal.Parse(txtTradeInValue.Text) < 0)
            {
                Console.WriteLine("Trade-in value cannot exceed the vehicle sale price.");

                txtSummaryVehiclesSalePrice.Text = null;
                txtSummaryOptions.Text = null;
                txtSummarySubtotal.Text = null;
                txtSummaryTax.Text = null;
                txtSummaryTotal.Text = null;
                txtSummaryTradeIn.Text = null;
                txtSummaryAmountDue.Text = null;
                txtFinanceMonthlyPay.Text = null;
            }
        }
        
        private void txtSummaryVehiclesSalePrice_TextChanged(object sender, EventArgs e)
        {
            string.Format("{0:C}", txtSummaryVehiclesSalePrice.Text);
        }

        private void txtSummaryOptions_TextChanged(object sender, EventArgs e)
        {
            decimal.Parse(txtSummaryOptions.Text);
        }

        private void txtSummarySubtotal_TextChanged(object sender, EventArgs e) 
        {
            string.Format("{0:C}", txtSummarySubtotal.Text);
        }

        private void txtSummaryTax_TextChanged(object sender, EventArgs e)
        {
            decimal.Parse(txtSummaryTax.Text);
        }

        private void txtSummaryTotal_TextChanged(object sender, EventArgs e)
        {
            string.Format("{0:C}", txtSummaryTotal.Text);
        }

        private void txtSummaryTradeIn_TextChanged(object sender, EventArgs e)
        {
            decimal.Parse(txtSummaryTradeIn.Text);
        }

        private void txtSummaryAmountDue_TextChanged(object sender, EventArgs e)
        {
            string.Format("{0:C}", txtSummaryAmountDue.Text);
        }

        private void txtFinanceMonthlyPay_TextChanged(object sender, EventArgs e)
        {
            string.Format("{0:C}", txtFinanceMonthlyPay.Text);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            string messageConfirmation = "Do you want to reset the form?";
            string caption = "Reset Form";
            MessageBoxButtons button = MessageBoxButtons.YesNo;
            MessageBoxIcon boxIcon = MessageBoxIcon.Warning;
            DialogResult messageBox = MessageBox.Show(messageConfirmation, caption, button, boxIcon);

            if (messageBox == System.Windows.Forms.DialogResult.Yes)
            {
                // Closes the parent form.
                Close();
            } 
        }

        private void chkStereoSystem_CheckedChanged(object sender, EventArgs e)
        {
            
        } 

        private void chkLeatherInterior_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkComputerNavigation_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radStandard_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radPearlized_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radCustomized_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void nudFinanceYears_ValueChanged(object sender, EventArgs e)
        {

        }

        private void nudFinanceInterestRate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
