﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRCAGMariahGarcia
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();

            this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
            this.btnAboutOk.Click += new System.EventHandler(this.btnAboutOk_Click);

        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAboutOk_Click(object sender, EventArgs e)
        {

        }
    }
}
