﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRCAGMariahGarcia
{
    public partial class RRCAutomotiveForm : Form
    {
        public RRCAutomotiveForm()
        {
            InitializeComponent();

            salesQuoteToolStripMenuItem.Click += new EventHandler(salesQuoteToolStripMenuItem_Click);
            carWashToolStripMenuItem.Click += new EventHandler(carWashToolStripMenuItem_Click);
            
            mnuFileExit.Click += new EventHandler(mnuFileExit_Click);
            mnuDataVehicle.Click += new EventHandler(mnuDataVehicle_Click);
            mnuHelpAbout.Click += new EventHandler(mnuHelpAbout_Click);

        }

        private void RRCAutomotiveForm_Load(object sender, EventArgs e)
        {
            salesQuoteToolStripMenuItem.Click += salesQuoteToolStripMenuItem_Click;
            mnuFileExit.Click += mnuFileExit_Click;
            mnuHelpAbout.Click += mnuHelpAbout_Click;

        }


        private void salesQuoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RRCAutomotiveForm form = new RRCAutomotiveForm();
            form.ShowDialog();
        }

        private void carWashToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mnuDataVehicle_Click(object sender, EventArgs e)
        {

        }

        private void mnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutForm form = new AboutForm();
            form.ShowDialog();
        }
    }
}
